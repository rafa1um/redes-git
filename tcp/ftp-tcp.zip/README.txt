terminal running: 

Hostname e Porta são passados por argumento:

	python3 nome_do_fonte.py HOST PORT

exemplo:
	
	python3 tcp_server.py 255.255.255.255 1234
	python3 tcp_client.py 255.255.255.255 1234
	
alunos:

	Rafael Yukio Umemoto
	João Vitor Barroso